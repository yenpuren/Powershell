# ps-cpu-stress

PowerShell module for generating CPU activity
